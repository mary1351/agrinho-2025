let cantor;
let itens = [];
let pontuacao = 0;
let tempoLimite = 30; // 30 segundos de jogo
let tempoInicial;
let jogoIniciado = false;
let estadoJogo = 'menu'; // 'menu', 'jogando', 'fim'

// --- Imagens (você pode substituir por suas próprias imagens ou usar formas simples) ---
let imgCantor;
let imgMilho;
let imgMicrofone;
let imgViolao;
let imgPredio;

function preload() {
  // Carregue suas imagens aqui. Se não tiver, o jogo usará formas simples.
  // Exemplo:
  // imgCantor = loadImage('assets/cantor.png');
  // imgMilho = loadImage('assets/milho.png');
  // imgMicrofone = loadImage('assets/microfone.png');
  // imgViolao = loadImage('assets/violao.png');
  // imgPredio = loadImage('assets/predio.png');
}

function setup() {
  createCanvas(800, 600);
  cantor = new Cantor();
  tempoInicial = millis(); // Guarda o tempo de início do jogo
  textFont('Georgia'); // Uma fonte que remete um pouco ao sertanejo
}

function draw() {
  background(135, 206, 235); // Céu azul

  if (estadoJogo === 'menu') {
    desenharMenu();
  } else if (estadoJogo === 'jogando') {
    atualizarJogo();
    desenharJogo();
  } else if (estadoJogo === 'fim') {
    desenharFimDeJogo();
  }
}

// --- Funções do Jogo ---

function desenharMenu() {
  textAlign(CENTER, CENTER);
  textSize(50);
  fill(255);
  text("Conexão Campo-Cidade: O Show!", width / 2, height / 2 - 50);

  textSize(20);
  fill(200);
  text("Cante e colete a harmonia entre o campo e a cidade!", width / 2, height / 2);
  
  textSize(30);
  fill(50, 200, 50);
  text("Clique para começar", width / 2, height / 2 + 80);
}

function atualizarJogo() {
  let tempoDecorrido = (millis() - tempoInicial) / 1000; // Tempo em segundos
  let tempoRestante = tempoLimite - tempoDecorrido;

  if (tempoRestante <= 0) {
    estadoJogo = 'fim';
    return;
  }

  cantor.mover();

  // Gera novos itens ocasionalmente
  if (frameCount % 60 === 0) { // A cada 60 frames (aprox. 1 segundo)
    itens.push(new Item());
  }

  for (let i = itens.length - 1; i >= 0; i--) {
    itens[i].mover();
    if (cantor.coletou(itens[i])) {
      pontuacao += itens[i].valor;
      itens.splice(i, 1); // Remove o item coletado
    } else if (itens[i].offscreen()) {
      itens.splice(i, 1); // Remove itens que saíram da tela
    }
  }
}

function desenharJogo() {
  // Desenha um horizonte simples para representar campo e cidade
  noStroke();
  fill(120, 180, 80); // Cor de grama
  rect(0, height * 0.7, width, height * 0.3); // Campo

  fill(100, 100, 100); // Cor de asfalto
  rect(0, height * 0.8, width, 50); // Estrada/rua

  // Desenha o cantor
  cantor.desenhar();

  // Desenha os itens
  for (let item of itens) {
    item.desenhar();
  }

  // Mostra a pontuação e o tempo
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Pontuação: " + pontuacao, 10, 10);

  let tempoRestante = ceil(tempoLimite - (millis() - tempoInicial) / 1000);
  textAlign(RIGHT, TOP);
  text("Tempo: " + tempoRestante, width - 10, 10);
}

function desenharFimDeJogo() {
  textAlign(CENTER, CENTER);
  textSize(60);
  fill(255, 0, 0);
  text("FIM DE JOGO!", width / 2, height / 2 - 60);

  textSize(30);
  fill(255);
  text("Sua Pontuação Final: " + pontuacao, width / 2, height / 2);

  textSize(20);
  fill(200);
  text("Clique para jogar novamente", width / 2, height / 2 + 60);
}

function mousePressed() {
  if (estadoJogo === 'menu') {
    estadoJogo = 'jogando';
    tempoInicial = millis();
    pontuacao = 0;
    itens = [];
  } else if (estadoJogo === 'fim') {
    estadoJogo = 'menu';
  }
}

// --- Classes do Jogo ---

class Cantor {
  constructor() {
    this.x = width / 2;
    this.y = height * 0.75; // Posição inicial no "campo"
    this.tamanho = 60;
    this.velocidade = 5;
  }

  desenhar() {
    if (imgCantor) {
      image(imgCantor, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
    } else {
      // Desenho simples se não houver imagem
      fill(255, 100, 100); // Cor da pele
      ellipse(this.x, this.y - 15, this.tamanho * 0.7, this.tamanho * 0.7); // Cabeça
      fill(0, 0, 150); // Roupa azul
      rect(this.x - 15, this.y, 30, 40); // Corpo
      fill(100, 50, 0); // Chapéu de caubói
      arc(this.x, this.y - 45, 60, 30, PI, TWO_PI);
      rect(this.x - 30, this.y - 35, 60, 5);
    }
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    // Limita o cantor dentro da tela
    this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);
  }

  coletou(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < this.tamanho / 2 + item.tamanho / 2;
  }
}

class Item {
  constructor() {
    this.x = random(width);
    this.y = random(-100, -10); // Começa acima da tela
    this.tamanho = 40;
    this.velocidade = random(1, 3);
    this.tipo = floor(random(2)); // 0 para campo, 1 para cidade
    this.valor = 1;
  }

  desenhar() {
    if (this.tipo === 0) { // Item do Campo
      if (imgMilho && imgViolao) {
        if (random() > 0.5) {
          image(imgMilho, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
        } else {
          image(imgViolao, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
        }
      } else {
        // Desenho simples se não houver imagem
        fill(255, 200, 0); // Milho
        triangle(this.x, this.y - 20, this.x - 20, this.y + 20, this.x + 20, this.y + 20);
      }
    } else { // Item da Cidade
      if (imgMicrofone && imgPredio) {
        if (random() > 0.5) {
          image(imgMicrofone, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
        } else {
          image(imgPredio, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
        }
      } else {
        // Desenho simples se não houver imagem
        fill(150); // Microfone
        rect(this.x - 10, this.y - 20, 20, 40);
        ellipse(this.x, this.y - 20, 25, 25);
      }
    }
  }

  mover() {
    this.y += this.velocidade;
  }

  offscreen() {
    return this.y > height + this.tamanho;
  }
}